#include <stdio.h>
#include <stdlib.h>
#include <avr/io.h>
#include "concurrency_func.h"

/* Called by the runtime system to select another process.
   "cursp" = the stack pointer for the currently running process
*/

/*
 * process_select takes the current stack pointer as an argument
 * it returns the stack pointer for the next process to run 
 * 
 * the process first checks to see if there are any processes on the ready queue
 * if not, it returns the current stack pointer without changing the current_process
 * 
 * if the current stack pointer is 0, meaning there is no current running process
 * the function pops the first process of the head of the stack off and saves it as the current_process
 * it increments the ready queue, and returns the previous head's stack pointer
 */
__attribute__((used)) unsigned int process_select (unsigned int cursp)
{
    // if no ready processes, continue with current process
    if (!head) {
      return cursp;         
    }

    //if no current process, don't add anything to queue 
    if (cursp == 0) {
        current_process = head;
      // advance the queue
        head = head->next;
      // NULL out current process' next variable 
        current_process->next = NULL;
        return current_process->sp;
      //dont add current process to the back of the queue.
    }

    // find the end of the process queue
    process_t *end = head;
    while (end->next) {
        end = end->next;
    } // OR just use tail

    // save the cursp into the current process
    current_process->sp = cursp;

    // add the current process to the back of the queue
    end->next = current_process;

    // set current_process to next ready process
    current_process = head;

    // advance the queue
    head = head->next;

    // NULL out current process' next variable
    current_process->next = NULL;

    // grab return value if any
    return current_process->sp;
}



/* Starts up the concurrent execution */
void process_start (void) {
    current_process = NULL;
    process_begin();
};


/* Create a new process */
/* 
 *  process_create creates a new process_t, 
 *  reserves space for the process' stack, 
 *  and adds the process_t to the ready queue
*/
int process_create (void (*f)(void), int n) {
    asm volatile("cli\n\t");
    unsigned int sp;
    process_t * proc = malloc(sizeof(process_t));
    if(!proc) {
        return -1;
    }
    if((sp = process_init (f, n)) == 0) {
        return -1;
    };
    proc->sp = sp;
    proc->next = head;
    head = proc;
    asm volatile("sei\n\t");
    return 0;
}

/* Lock init sets the value of the lock
 * Since interrupts are disabled, this function is atomic.
 * Under normal circumstances we would allocate space for the lock in this function too
 * However, for some reason, malloc is not working inside this function, ref Office Hours w/ Kasey
 * So we are mallocing in the .ino file instead.
 */
void lock_init (lock_t *l) {
  asm volatile("cli\n\t");
  // l = (lock_t*) malloc(sizeof(lock_t));
  l->lock = false; 
  asm volatile("sei\n\t");
  return;
}

/* Lock acquire sets the lock to true 
 * Since interrupts are disabled, this function is atomic.
 * Every other process that tries to acquire the lock after it has already been acquired will
 * be blocked and automatically yield to the next waiting process until the lock has been released.
 * Our implementation puts all blocked processes back onto the waiting queue, but as long as they
 * are blocked, they will automatically yield their time each time they are switched to.
 * Once the lock is released, the next process to check the condition will acquire the lock.
 */
void lock_acquire (lock_t *l){
  asm volatile("cli\n\t");
  while (l->lock) {
    yield();
  }

  l->lock = true;
  asm volatile("sei\n\t");
}

/* Lock release sets the lock to false
 * Since interrupts are disabled, this function is atomic.
 */
void lock_release (lock_t *l){
  asm volatile("cli\n\t");
  l->lock = false;
  asm volatile("sei\n\t");
}
